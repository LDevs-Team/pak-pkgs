## Unreleased

### Feat

- added pak support !

## v12.0.1 (2023-09-23)

### Fix

- forced reg add in setup !

## v12.0.0 (2023-09-23)

### Feat

- added DiSHLoader registry setup !

## v11.4.2 (2023-09-14)

### Fix

- fixed CI variables !

## v11.4.1 (2023-09-14)

### Fix

- fixed CI !

## v11.4.0 (2023-09-14)

### Feat

- added codeql to readme !

### Fix

- fixed CI fetch-depth
- fixed CI syntax !
- fixing CI (commit 1) !
- tried to fix stuff !

## v11.3.0 (2023-09-13)

### Feat

- auto bump in setup

### Fix

- updated README !
- updated setup.bat

## v11.2.0 (2023-09-10)

### Feat

- added pack and added back playsound
- transtioned to bot and added jishaku !

## v11.1.1 (2023-07-07)

### Fix

- removed outdated components from zip !
- added full DiSHLoader support |
- removed Service support |

## v11.1.0 (2023-07-07)

### Feat

- unified setup with DiSHLoader directories !
- updated deleter
- updated shell:startup setup to be unified
- unified with DiSHLoader

## v11.0.0 (2023-07-06)

### Feat

- supporting DiSHLoader !

### Fix

- clarify some stuff !
- corrected link
- compatibility on Readme

## v10.2.0 (2023-06-24)

### Feat

- **docs**: added smth on docs
- added CodeQL

### Fix

- **readme**: fixed stuff
- **docs**: fixed warnings
- **dependabot**: made daily for security
- **readme**: codacy breaking my balls
- **help**: fixed help messages !
- **scripting**: fixed submodule ig
- **scripting**: fixed scripting commit
- **dependabot**: fixed package ecosystem

## v10.1.0 (2023-01-05)

### Feat

- **LICENSE**: switched to MIT !

### Fix

- **ci**: fixed broken builds !
- **setupshellstartup**: works

## v10.0.0 (2023-01-03)

### Feat

- removed Mac !
- added stuff to zip
- added bck services + QoL stuff !

## v9.2.0 (2023-01-03)

### Feat

- added ch mention !
- badge lul
- **ci**: add stuff !

### Fix

- fixed channel where the message is being sent !
- added pydub req ! feat: added help !
- **ci**: fixed ci deploy !
- github actions IDK
- IDK what to say
- **ci**: github workflow syntax is hell
- **ci**: sudo !
- **ci**: GitHub f*ck your editor
- **ci**: trying to fix workflow syntax
- **ci**: fixed CI on linux !
- no longer need ffmpeg !


- changed some namings !

## v9.1.0 (2022-12-11)

### Feat

- removed "not found in overrides" message !
- add camera control

### Fix

- **play**: fixed audio playing (ffmpeg used ig)
- revert "refactor to NamedTemporanyFile"

## v9.0.0 (2022-12-10)

### Feat

- **ci**: trying to add MacOS !

### Fix

- fixed build no. !
- **ci**: fixed CI artifacts download !
- fixed requirements !
- **ci**: fixed setup python !
- **ci**: fixed MacOS ci to force using python 3.11

## v8.3.1 (2022-12-08)

### Feat

- added mouse movement !
- added keyboard commands

### Fix

- **play**: fixed playsound not working !
- allow "." in hostname

## v8.3.0 (2022-11-13)

### Feat

- **ci**: only make release when asked

## v8.2.0 (2022-11-13)

### Fix

- added cz to zip !

## v8.1.0 (2022-11-13)

### Feat

- **log**: log now prints the version

## v8.0.0 (2022-11-13)

### Feat

- added logging

### Fix

- fixed CI
- **ignore**: fixed gitignore

## v7.3.5 (2022-11-13)

### Fix

- **ci**: fixed syntax
- **ci**: trying to fix CI versioning
- **ci**: fix CI to some extent
- **cz**: reverted
- **cz**: reverted version
- **ci**: hopefully fixed CI push
- **ci**: fixing CI
- fixed syntax
- **ci**: fixed credentials
- **ci**: fixed cz
- **ci**: fixed syntax
- **ci**: fixing permissions
- **ci**: fixed SyntaxError in CI
- **CI**: fixing CI
- **ci**: trying to fix CI
- **ci**: fixed CI ig
- **cz**: trying to fix commitzen
- **installer**: fixed installer
- **docs**: fixed indent
- **docs**: fixed README.md

## v7.3.4 (2022-09-20)

## v7.3.3 (2022-09-20)

### Fix

- **build**: fixed platform import

## v7.3.2 (2022-09-20)

### Fix

- **build**: fixed yaml import

## v7.3.1 (2022-09-20)

### Fix

- **build**: fixed builds

## v7.3.0 (2022-09-20)

### Feat

- **ci**: releases are now made based off commits and SemVer

### Fix

- **ci**: fixed ci builds cause requirements

## v7.2.1 (2022-09-20)

### Fix

- **ci**: fixed cz with official action for CI

## v7.2.0 (2022-09-20)

### Feat

- **ci**: use Bash
- **ci**: Fixed Linux, windows and MacOS incoming
- **CI**: testing part 69
- **env**: removed unnecessary prints
- v7

### Fix

- **cz**: fixed commitzen
- **CI**: fixed checkout version
- **env**: works
- **ci**: use bash shell on default
